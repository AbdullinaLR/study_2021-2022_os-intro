---
## Front matter
lang: ru-RU
title: Добавить с сайту все остальные элементы
author: Leysan R. Abdullina
institute: |
	RUDN University, Moscow, Russian Federation

date: NEC--2022, 24 May

## Formatting
toc: false
slide_level: 2
theme: metropolis
header-includes: 
 - \metroset{progressbar=frametitle,sectionpage=progressbar,numbering=fraction}
 - '\makeatletter'
 - '\beamer@ignorenonframefalse'
 - '\makeatother'
aspectratio: 43
section-titles: true
---

# Индивидуальный проект. Добавить с сайту все остальные элементы

## Цель работы

Добавить с сайту все остальные элементы.

## Задачи

- Сделать записи для персональных проектов.
- Сделать пост по прошедшей неделе.
- Добавить пост на тему "Языки научного программирования".

## Теоретическое введение

- Для реализации сайта используется генератор статических сайтов Hugo.

- Общие файлы для тем Wowchemy:
        Репозиторий: https://github.com/wowchemy/wowchemy-hugo-themes
        
- В качестве шаблона индивидуального сайта используется шаблон Hugo Academic Theme.
        Демо-сайт: https://academic-demo.netlify.app/
        Репозиторий: https://github.com/wowchemy/starter-hugo-academic



## Выполнение работы

Первым шагом мы перешли в work/blog/content/projects, где мы создали 2 новые папки для создания наших двух проектов. А также скопировали туда файлы index.md для дальшейго редактирования. (скриншот [-@fig:001])

![Создание папок проектов](photo/1.png){#fig:001 width=100%}

## Выполнение работы

Вторым шагом мы редактировали наши файлы - писали информацию о проекте и его содержимое. (скриншоты [-@fig:002], [-@fig:003])

![Создание проекта 1](photo/4.png){#fig:002 width=100%}

## Выполнение работы

![Создание проекта 2](photo/5.png){#fig:003 width=100%}

## Выполнение работы

Далее мы написали 2 поста: один о прошедшей неделе и научные языки программирования. Для этого мы перешли в каталог work/blog/content/posts и создали 2 папки для соответствующих постов. (скриншоты [-@fig:004], [-@fig:005], [-@fig:006])

## Выполнение работы

![Создание папок постов](photo/2.png){#fig:004 width=100%}

## Выполнение работы

![Написание поста о прошлой неделе](photo/3.png){#fig:005 width=100%}

## Выполнение работы

![Написание поста о языках программирования](photo/3.png){#fig:006 width=100%}

## Выполнение работы

Последним нашим шагом было "запушить" всю новую информацию и пронаблюдать за изменениями на нашем сайте. (скриншоты [-@fig:007])

![Появление новых проектов](photo/7.png){#fig:007 width=100%}

## Выводы

В ходе лабораторной работы мы смогли добавить с сайту все остальные элементы и выполинили все задачи.

## Спасибо за внимание!!

## Список литературы

https://esystem.rudn.ru/mod/page/view.php?id=862706
https://esystem.rudn.ru/mod/page/view.php?id=862707
https://yamadharma.github.io/ru/course/os-intro/educational-project-researcher-website/

---
## Front matter
title: "РОССИЙСКИЙ УНИВЕРСИТЕТ ДРУЖБЫ НАРОДОВ"
subtitle: "Добавить с сайту все остальные элементы"
author: "Абдуллина Ляйсан Раисвона НПИбд-01-21"

## Generic otions
lang: ru-RU
toc-title: "Содержание"

## Bibliography
bibliography: bib/cite.bib
csl: pandoc/csl/gost-r-7-0-5-2008-numeric.csl

## Pdf output format
toc: true # Table of contents
toc-depth: 2
lof: true # List of figures
fontsize: 12pt
linestretch: 1.5
papersize: a4
documentclass: scrreprt
## I18n polyglossia
polyglossia-lang:
  name: russian
  options:
	- spelling=modern
	- babelshorthands=true
polyglossia-otherlangs:
  name: english
## I18n babel
babel-lang: russian
babel-otherlangs: english
## Fonts
mainfont: PT Serif
romanfont: PT Serif
sansfont: PT Sans
monofont: PT Mono
mainfontoptions: Ligatures=TeX
romanfontoptions: Ligatures=TeX
sansfontoptions: Ligatures=TeX,Scale=MatchLowercase
monofontoptions: Scale=MatchLowercase,Scale=0.9
## Biblatex
biblatex: true
biblio-style: "gost-numeric"
biblatexoptions:
  - parentracker=true
  - backend=biber
  - hyperref=auto
  - language=auto
  - autolang=other*
  - citestyle=gost-numeric
## Pandoc-crossref LaTeX customization
figureTitle: "Скриншот"
tableTitle: "Таблица"
listingTitle: "Листинг"
lofTitle: "Список иллюстраций"
lotTitle: "Список таблиц"
lolTitle: "Листинги"
## Misc options
indent: true
header-includes:
  - \usepackage{indentfirst}
  - \usepackage{float} # keep figures where there are in the text
  - \floatplacement{figure}{H} # keep figures where there are in the text
---

# Цель работы

Добавить с сайту все остальные элементы.

## Задачи

- Сделать записи для персональных проектов.
- Сделать пост по прошедшей неделе.
- Добавить пост на тему "Языки научного программирования".


# Теоретическое введение

- Для реализации сайта используется генератор статических сайтов Hugo.

- Общие файлы для тем Wowchemy:
        Репозиторий: https://github.com/wowchemy/wowchemy-hugo-themes
        
- В качестве шаблона индивидуального сайта используется шаблон Hugo Academic Theme.
        Демо-сайт: https://academic-demo.netlify.app/
        Репозиторий: https://github.com/wowchemy/starter-hugo-academic

,
# Выполнение индивидульного проекта

##1

Первым шагом мы перешли в work/blog/content/projects, где мы создали 2 новые папки для создания наших двух проектов. А также скопировали туда файлы index.md для дальшейго редактирования. (скриншот [-@fig:001])

![Создание папок проектов](photo/1.png){#fig:001 width=100%}

##2

Вторым шагом мы редактировали наши файлы - писали информацию о проекте и его содержимое. (скриншоты [-@fig:002], [-@fig:003])

![Создание проекта 1](photo/4.png){#fig:002 width=100%}

![Создание проекта 2](photo/5.png){#fig:003 width=100%}

##3

Далее мы написали 2 поста: один о прошедшей неделе и научные языки программирования. Для этого мы перешли в каталог work/blog/content/posts и создали 2 папки для соответствующих постов. (скриншоты [-@fig:004], [-@fig:005], [-@fig:006])

![Создание папок постов](photo/2.png){#fig:004 width=100%}

![Написание поста о прошлой неделе](photo/3.png){#fig:005 width=100%}

![Написание поста о языках программирования](photo/3.png){#fig:006 width=100%}

##3

Последним нашим шагом было "запушить" всю новую информацию и пронаблюдать за изменениями на нашем сайте. (скриншоты [-@fig:007])

![Появление новых проектов](photo/7.png){#fig:007 width=100%}

# Выводы

В ходе лабораторной работы мы смогли добавить с сайту все остальные элементы и выполинили все задачи.

# Список литературы

https://esystem.rudn.ru/mod/page/view.php?id=862706
https://esystem.rudn.ru/mod/page/view.php?id=862707
https://yamadharma.github.io/ru/course/os-intro/educational-project-researcher-website/
:::

---
## Front matter
title: "РОССИЙСКИЙ УНИВЕРСИТЕТ ДРУЖБЫ НАРОДОВ"
subtitle: "Добавить к сайту данные о себе."
author: "Абдуллина Ляйсан Раисвона НПИбд-01-21"

## Generic otions
lang: ru-RU
toc-title: "Содержание"

## Bibliography
bibliography: bib/cite.bib
csl: pandoc/csl/gost-r-7-0-5-2008-numeric.csl

## Pdf output format
toc: true # Table of contents
toc-depth: 2
lof: true # List of figures
fontsize: 12pt
linestretch: 1.5
papersize: a4
documentclass: scrreprt
## I18n polyglossia
polyglossia-lang:
  name: russian
  options:
	- spelling=modern
	- babelshorthands=true
polyglossia-otherlangs:
  name: english
## I18n babel
babel-lang: russian
babel-otherlangs: english
## Fonts
mainfont: PT Serif
romanfont: PT Serif
sansfont: PT Sans
monofont: PT Mono
mainfontoptions: Ligatures=TeX
romanfontoptions: Ligatures=TeX
sansfontoptions: Ligatures=TeX,Scale=MatchLowercase
monofontoptions: Scale=MatchLowercase,Scale=0.9
## Biblatex
biblatex: true
biblio-style: "gost-numeric"
biblatexoptions:
  - parentracker=true
  - backend=biber
  - hyperref=auto
  - language=auto
  - autolang=other*
  - citestyle=gost-numeric
## Pandoc-crossref LaTeX customization
figureTitle: "Скриншот"
tableTitle: "Таблица"
listingTitle: "Листинг"
lofTitle: "Список иллюстраций"
lotTitle: "Список таблиц"
lolTitle: "Листинги"
## Misc options
indent: true
header-includes:
  - \usepackage{indentfirst}
  - \usepackage{float} # keep figures where there are in the text
  - \floatplacement{figure}{H} # keep figures where there are in the text
---

# Цель работы

Добавить к сайту данные о себе.

## Задачи

- Разместить фотографию владельца сайта.
- Разместить краткое описание владельца сайта (Biography).
- Добавить информацию об интересах (Interests).
- Добавить информацию от образовании (Education).
- Сделать пост по прошедшей неделе.
- Добавить пост на тему управление версиями. Git.

# Теоретическое введение

- Для реализации сайта используется генератор статических сайтов Hugo.

- Общие файлы для тем Wowchemy:
        Репозиторий: https://github.com/wowchemy/wowchemy-hugo-themes
        
- В качестве шаблона индивидуального сайта используется шаблон Hugo Academic Theme.
        Демо-сайт: https://academic-demo.netlify.app/
        Репозиторий: https://github.com/wowchemy/starter-hugo-academic



# Выполнение индивидульного проекта

##1
 
Первым шагом мы заходим в каталог /work/blog/content/authors/admin. Доавляю туда своб фото поди именем avatar. (скриншот [-@fig:001])

![Размешение фотографии профиля](photo/1.png){#fig:001 width=100%}

##2

Далее мы все в том же каталоге открываем файл _index.md и начинаем редактировать информацию нашего профиля (Biography, Interests, Education) (скриншот [-@fig:002])

![Редактирум профиль](photo/2.png){#fig:002 width=100%}

##3

Теперь мы переходим в каталог /work/blog/content/post и создаем там 2 новые папки - они и будут являться нашими постами. А также не забудем скопировать в наши новые папки шаблоны для постов, то есть _index.md (скриншот [-@fig:003])

![Создание папок для постов](photo/3.png){#fig:003 width=100%}

##4

Теперь нам остается только отредактировать наши шаблоны, для получения двух новых постов: о том, как мы провели нашу прошлую неделю и пост об управлении версий. (скриншоты [-@fig:004], [-@fig:005])

![Создание поста о прошедшей неделе](photo/4.png){#fig:004 width=100%}

![Создание поста об управлии версий](photo/5.png){#fig:005 width=100%}

##5

После всех изменний мы следуем в /work/blog/config/_default и открываем файл config.yalm. Здесь в 7 строчке мы меняем BaseURL с example.com на наш сайт. (скриншот [-@fig:006])

![Изменение URL в файле config.yalm](photo/6.png){#fig:006 width=100%}

##6

После всех проделанных операций нам остаются лишь все "запушить". Для начала через cd переходим в /work/blog, где мы прописываем команду hugo. После небольшого ожидания мы перехоим в каталог public, где прописываем следующие команды: (скриншоты [-@fig:007], [-@fig:008])

- git add .
- git commit -am "update2"
- git push origin main

![Прописывание команды hugo](photo/7.png){#fig:007 width=100%}

![Прописывание команд git](photo/8.png){#fig:008 width=100%}

##7

Последний шаг - удостовериться, что все получилось. Переходим на наш сайт и смотрим на результат (скриншот [-@fig:009])

![Наш сайт](photo/9.png){#fig:009 width=100%}

# Выводы

В ходе лабораторной работы мы смогли добавить к сайту данные о себе.

# Список литературы

https://esystem.rudn.ru/mod/page/view.php?id=862706
https://esystem.rudn.ru/mod/page/view.php?id=862707
https://yamadharma.github.io/ru/course/os-intro/educational-project-researcher-website/
:::

---
## Front matter
title: "РОССИЙСКИЙ УНИВЕРСИТЕТ ДРУЖБЫ НАРОДОВ"
subtitle: "Добавить к сайту достижения"
author: "Абдуллина Ляйсан Раисвона НПИбд-01-21"

## Generic otions
lang: ru-RU
toc-title: "Содержание"

## Bibliography
bibliography: bib/cite.bib
csl: pandoc/csl/gost-r-7-0-5-2008-numeric.csl

## Pdf output format
toc: true # Table of contents
toc-depth: 2
lof: true # List of figures
fontsize: 12pt
linestretch: 1.5
papersize: a4
documentclass: scrreprt
## I18n polyglossia
polyglossia-lang:
  name: russian
  options:
	- spelling=modern
	- babelshorthands=true
polyglossia-otherlangs:
  name: english
## I18n babel
babel-lang: russian
babel-otherlangs: english
## Fonts
mainfont: PT Serif
romanfont: PT Serif
sansfont: PT Sans
monofont: PT Mono
mainfontoptions: Ligatures=TeX
romanfontoptions: Ligatures=TeX
sansfontoptions: Ligatures=TeX,Scale=MatchLowercase
monofontoptions: Scale=MatchLowercase,Scale=0.9
## Biblatex
biblatex: true
biblio-style: "gost-numeric"
biblatexoptions:
  - parentracker=true
  - backend=biber
  - hyperref=auto
  - language=auto
  - autolang=other*
  - citestyle=gost-numeric
## Pandoc-crossref LaTeX customization
figureTitle: "Скриншот"
tableTitle: "Таблица"
listingTitle: "Листинг"
lofTitle: "Список иллюстраций"
lotTitle: "Список таблиц"
lolTitle: "Листинги"
## Misc options
indent: true
header-includes:
  - \usepackage{indentfirst}
  - \usepackage{float} # keep figures where there are in the text
  - \floatplacement{figure}{H} # keep figures where there are in the text
---

# Цель работы

Добавить к сайту достижения

## Задачи

- Добавить информацию о навыках (Skills).
- Добавить информацию об опыте (Experience).
- Добавить информацию о достижениях (Accomplishments).
- Сделать пост по прошедшей неделе.
 -Добавить пост на тему "Язык разметки Markdown".


# Теоретическое введение

- Для реализации сайта используется генератор статических сайтов Hugo.

- Общие файлы для тем Wowchemy:
        Репозиторий: https://github.com/wowchemy/wowchemy-hugo-themes
        
- В качестве шаблона индивидуального сайта используется шаблон Hugo Academic Theme.
        Демо-сайт: https://academic-demo.netlify.app/
        Репозиторий: https://github.com/wowchemy/starter-hugo-academic



# Выполнение индивидульного проекта

##1
 
Первым шагом мы заходим в каталог /work/blog/content/home. Здесь ищем необходимые нам файлы (Skiils, Accomplishments, Experince) и редактриуем их. (скриншоты [-@fig:001], [-@fig:002], [-@fig:003],[-@fig:004])

![Переход в нужную папку](photo/1.png){#fig:001 width=100%}

![Редактирование Accomplishments](photo/2.png){#fig:002 width=100%}

![Редактирование Experince](photo/3.png){#fig:003 width=100%}

![Редактирование Skills](photo/4.png){#fig:004 width=100%}

##2

Далее мы переходим в /work/blog/content/post. Создаем 2 новые папки для наших постов. Один из них посвещаем прошедшей неделе (lastweek2), второй же - языку разметки Markdown. (скриншоты [-@fig:005], [-@fig:006], [-@fig:007])

![Переход в нужный каталог](photo/5.png){#fig:005 width=100%}

![Пишем пост о прошедшей неделе](photo/6.png){#fig:006 width=100%}

![Пишем пост про Markdown](photo/7.png){#fig:007 width=100%}

##3

Последгим шагом нам остаётся лишь "запушить" всю новую информацию через консоль и убедиться в правильности выполнения работы на нашем сайте. (скриншоты [-@fig:008], [-@fig:009], [-@fig:010],  [-@fig:011],  [-@fig:012])

![Пушим через консоль](photo/8.png){#fig:008 width=100%}

![Изменение в Skills](photo/9.png){#fig:009 width=100%}

![Изменение в Experience](photo/10.png){#fig:010 width=100%}

![Изменение в Accomplishments](photo/11.png){#fig:011 width=100%}

![Изменения в постах](photo/12.png){#fig:012 width=100%}



# Выводы

В ходе лабораторной работы мы смогли добавить к сайту достижения

# Список литературы

https://esystem.rudn.ru/mod/page/view.php?id=862706
https://esystem.rudn.ru/mod/page/view.php?id=862707
https://yamadharma.github.io/ru/course/os-intro/educational-project-researcher-website/
:::

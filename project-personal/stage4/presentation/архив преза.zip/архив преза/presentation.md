---
## Front matter
lang: ru-RU
title: Добавить к сайту достижения.
author: Leysan R. Abdullina
institute: |
	RUDN University, Moscow, Russian Federation

date: NEC--2022, 29 April

## Formatting
toc: false
slide_level: 2
theme: metropolis
header-includes: 
 - \metroset{progressbar=frametitle,sectionpage=progressbar,numbering=fraction}
 - '\makeatletter'
 - '\beamer@ignorenonframefalse'
 - '\makeatother'
aspectratio: 43
section-titles: true
---

# Индивидуальный проект. Добавить к сайту достижения.

## Цель работы

Добавить к сайту ссылки на научные и библиометрические ресурсы.

## Задачи

- Зарегистрироваться на соответствующих ресурсах и разместить на них ссылки на сайте:
1. eLibrary : https://elibrary.ru/;
2. Google Scholar : https://scholar.google.com/;
3. ORCID : https://orcid.org/;
4. Mendeley : https://www.mendeley.com/;
5. ResearchGate : https://www.researchgate.net/;
6. Academia.edu : https://www.academia.edu/;
7. arXiv : https://arxiv.org/;
8. github : https://github.com/.

- Сделать пост по прошедшей неделе.

- Добавить пост на тему "Оформление отчёта".

## #Теоретическое введение

- Для реализации сайта используется генератор статических сайтов Hugo.

- Общие файлы для тем Wowchemy:
        Репозиторий: https://github.com/wowchemy/wowchemy-hugo-themes
        
- В качестве шаблона индивидуального сайта используется шаблон Hugo Academic Theme.
        Демо-сайт: https://academic-demo.netlify.app/
        Репозиторий: https://github.com/wowchemy/starter-hugo-academic



## Выполнение работы

##1
 
Первым шагом мы заходим регистрируемся на всех сайтах, указанных в Задачах.(скриншоты [-@fig:001], [-@fig:002], [-@fig:003],[-@fig:004],[-@fig:005], [-@fig:006], [-@fig:007],[-@fig:008])

![Профиль на eLIBRARY.ru](photo/1.png){#fig:001 width=100%}

## Выполнение работы

![Профиль на Google Академия](photo/2.png){#fig:002 width=100%}

## Выполнение работы

![Профиль на ORCiD](photo/3.png){#fig:003 width=100%}

## Выполнение работы

![Профиль на Mendeley](photo/4.png){#fig:004 width=100%}

## Выполнение работы

![Профиль на ResearchGate](photo/5.png){#fig:005 width=100%}

## Выполнение работы

![Профиль на Academia.edu](photo/6.png){#fig:006 width=100%}

## Выполнение работы

![Профиль на ArXiv](photo/7.png){#fig:007 width=100%}

## Выполнение работы

![Профиль на Гитхабе](photo/8.png){#fig:008 width=100%}

##2

Вторым шагом было размещение ссылок на наш профиль. Для этого мы перешли в каталог work/blog/content/authors и открыли файл _index.md, где в графе socials, мы указали все нужные ссылки. (скриншот [-@fig:009])

![Редактирование файла _index.md](photo/10.png){#fig:009 width=100%}

## Выполнение работы

##3

Далее мы написали 2 поста: один о прошедшей неделе и один про оформление отчета. Для этого мы перешли в каталог work/blog/content/posts и создали 2 папки для соответствующих постов. (скриншоты [-@fig:010], [-@fig:011])

![Написание поста об оформлении отчета](photo/9.png){#fig:010 width=100%}

## Выполнение работы

![Написание поста о прошлой неделе](photo/11.png){#fig:011 width=100%}

##3

Последним нашим шагом было "запушить" всю новую информацию и пронаблюдать за изменениями на нашем сайте. (скриншоты [-@fig:012], [-@fig:013], [-@fig:014], [-@fig:015])

!["Пушим" информацию](photo/12.png){#fig:012 width=100%}

## Выполнение работы

![Появление новых ссылок](photo/13.png){#fig:013 width=100%}

## Выполнение работы

![Появление поста о прошлой неделе](photo/15.png){#fig:014 width=100%}

## Выполнение работы

![Появление об оформлении отчета](photo/14.png){#fig:015 width=100%}


## Выводы

В ходе лабораторной работы мы смогли добавить к сайту ссылки на научные и библиометрические ресурсы.

## Спасибо за внимание!!

## Список литературы

https://esystem.rudn.ru/mod/page/view.php?id=862706
https://esystem.rudn.ru/mod/page/view.php?id=862707
https://yamadharma.github.io/ru/course/os-intro/educational-project-researcher-website/

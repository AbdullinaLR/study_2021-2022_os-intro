---
## Front matter
title: "РОССИЙСКИЙ УНИВЕРСИТЕТ ДРУЖБЫ НАРОДОВ"
subtitle: "Размещение двуязычного сайта на Github."
author: "Абдуллина Ляйсан Раисвона НПИбд-01-21"

## Generic otions
lang: ru-RU
toc-title: "Содержание"

## Bibliography
bibliography: bib/cite.bib
csl: pandoc/csl/gost-r-7-0-5-2008-numeric.csl

## Pdf output format
toc: true # Table of contents
toc-depth: 2
lof: true # List of figures
fontsize: 12pt
linestretch: 1.5
papersize: a4
documentclass: scrreprt
## I18n polyglossia
polyglossia-lang:
  name: russian
  options:
	- spelling=modern
	- babelshorthands=true
polyglossia-otherlangs:
  name: english
## I18n babel
babel-lang: russian
babel-otherlangs: english
## Fonts
mainfont: PT Serif
romanfont: PT Serif
sansfont: PT Sans
monofont: PT Mono
mainfontoptions: Ligatures=TeX
romanfontoptions: Ligatures=TeX
sansfontoptions: Ligatures=TeX,Scale=MatchLowercase
monofontoptions: Scale=MatchLowercase,Scale=0.9
## Biblatex
biblatex: true
biblio-style: "gost-numeric"
biblatexoptions:
  - parentracker=true
  - backend=biber
  - hyperref=auto
  - language=auto
  - autolang=other*
  - citestyle=gost-numeric
## Pandoc-crossref LaTeX customization
figureTitle: "Скриншот"
tableTitle: "Таблица"
listingTitle: "Листинг"
lofTitle: "Список иллюстраций"
lotTitle: "Список таблиц"
lolTitle: "Листинги"
## Misc options
indent: true
header-includes:
  - \usepackage{indentfirst}
  - \usepackage{float} # keep figures where there are in the text
  - \floatplacement{figure}{H} # keep figures where there are in the text
---

# Цель работы

Размещение двуязычного сайта на Github.

## Задачи


- Сделать поддержку английского и русского языков.
- Разместить элементы сайта на обоих языках.
- Разместить контент на обоих языках.
- Сделать пост по прошедшей неделе.
- Добавить пост на тему по выбору (на двух языках).



# Теоретическое введение

- Для реализации сайта используется генератор статических сайтов Hugo.

- Общие файлы для тем Wowchemy:
        Репозиторий: https://github.com/wowchemy/wowchemy-hugo-themes
        
- В качестве шаблона индивидуального сайта используется шаблон Hugo Academic Theme.
        Демо-сайт: https://academic-demo.netlify.app/
        Репозиторий: https://github.com/wowchemy/starter-hugo-academic

,
# Выполнение индивидульного проекта

##1

Первым шагом мы перешли в work/blog/config/_default, где мы отредактировали 3 файла languages.yalm, comfig.yalm, menus.yalm. Мы разкомментили некоторые строчку так, чтобы у нас была поддержка двух языков: русского и английского (скриншоты [-@fig:001], [-@fig:002], [-@fig:003])

![Редактирование файла languages.yalm](photo/1.png){#fig:001 width=100%}

![Редактирование файла comfig.yalm](photo/3.png){#fig:002 width=100%}

![Редактирование файла menus.yalm](photo/6.png){#fig:003 width=100%}

##2

Вторым шагом мы перешли в work/blog/content/, где создали 2 папки для соответсующих языков и скопировали в них все содержимое. (скриншот[-@fig:004])

![Создание папок](photo/2.png){#fig:004 width=100%}

##3

Далее мы написали 2 поста: один о прошедшей неделе и о этапах реализации проекта. Для этого мы перешли в каталог work/blog/content/posts и создали 2 папки для соответствующих постов. Проделали эту операцию для en и ru (скриншоты [-@fig:005], [-@fig:006])

![Написание поста о прошлой неделе](photo/8.png){#fig:005 width=100%}

![Написание поста оэтапах реализации проекта](photo/9.png){#fig:006 width=100%}

##3

Последним нашим шагом было "запушить" всю новую информацию и пронаблюдать за изменениями на нашем сайте. (скриншоты [-@fig:007], [-@fig:008])

![Пушим](photo/4.png){#fig:007 width=100%}

![Появление новых проектов](photo/7.png){#fig:008 width=100%}

# Выводы

В ходе лабораторной работы мы смогли разместить двуязычный сайт на Github и выполинили все задачи.

# Список литературы

https://esystem.rudn.ru/mod/page/view.php?id=862706
https://esystem.rudn.ru/mod/page/view.php?id=862707
https://yamadharma.github.io/ru/course/os-intro/educational-project-researcher-website/
:::

---
## Front matter
title: "РОССИЙСКИЙ УНИВЕРСИТЕТ ДРУЖБЫ НАРОДОВ"
subtitle: "Лабораторная работа №3. Markdown"
author: "Абдуллина Ляйсан Раисовна НПИбд-01-21"

## Generic otions
lang: ru-RU
toc-title: "Содержание"

## Bibliography
bibliography: bib/cite.bib
csl: pandoc/csl/gost-r-7-0-5-2008-numeric.csl

## Pdf output format
toc-depth: 2
lof: true # List of figures
fontsize: 12pt
linestretch: 1.5
papersize: a4
documentclass: scrreprt
## I18n polyglossia
polyglossia-lang:
  name: russian
  options:
	- spelling=modern
	- babelshorthands=true
polyglossia-otherlangs:
  name: english
## I18n babel
babel-lang: russian
babel-otherlangs: english
## Fonts
mainfont: PT Serif
romanfont: PT Serif
sansfont: PT Sans
monofont: PT Mono
mainfontoptions: Ligatures=TeX
romanfontoptions: Ligatures=TeX
sansfontoptions: Ligatures=TeX,Scale=MatchLowercase
monofontoptions: Scale=MatchLowercase,Scale=0.9
## Biblatex
biblatex: true
biblio-style: "gost-numeric"
biblatexoptions:
  - parentracker=true
  - backend=biber
  - hyperref=auto
  - language=auto
  - autolang=other*
  - citestyle=gost-numeric
## Pandoc-crossref LaTeX customization
figureTitle: "Скриншот"
tableTitle: "Таблица"
listingTitle: "Листинг"
lofTitle: "Список иллюстраций"
lotTitle: "Список таблиц"
lolTitle: "Листинги"
## Misc options
indent: true
header-includes:
  - \usepackage{indentfirst}
  - \usepackage{float} # keep figures where there are in the text
  - \floatplacement{figure}{H} # keep figures where there are in the text
---

# Цель работы

Научиться оформлять отчёты с помощью легковесного языка разметки Markdown.

# Теоретическое введение

1. Чтобы создать заголовок,используйте знак ( # ).
2. Чтобы задать для текста полужирное начертание, заключите его в двойные звездочки.
3. Чтобы задать для текста курсивное начертание,заключите его в одинарные звездочки.
4. Чтобы задатьдля текста полужирное и курсивное начертание,заключите его втройные вездочки.
5. Неупорядоченный (маркированный) список можно отформатировать с помощью звездочек или тире.
6. Чтобы вложить один список в другой, добавьте отступдля элементовдочернего списка.
7. Синтаксис Markdown для встроенной ссылки состоит из части [link text] ,представляющей текстгиперссылки,и части (file-name.md) –URL-адреса или имени файла, на который дается ссылка:
 [link text](file-name.md)

# Выполнение лабораторной работы 

1. **Оформление отчета**

Нами был использован шаблон отчета, приведенный в ТУИСе. Отредактирум персональные данные. (скриншот [-@fig:001])

![Изменение шаблона](photo/1.png){#fig:001 width=100%}

Также заменим Figure на сло Скриншот (скриншот [-@fig:002])

![Изменение Figure](photo/2.png){#fig:002 width=100%}

Далее мы заполняли Теоретическое Введение, прописали базовые команды для выполнения Лабораторной работы №2. (скриншот [-@fig:003])

![Заполнение Теоретического Введения](photo/3.png){#fig:003 width=100%}

Следующим шагом было копирование уже сущетвующего отчета из word в необходимый нам формат. Также мы использовали ссылки на скриншоты в виде ссылок. (скриншот [-@fig:004])

![Пример оформления Хода выолнения Лабораторной работы и использование ссылок на фото/скрины](photo/4.png){#fig:004 width=100%}

Затем мы отвечали на Контрольные вопросы, ответы на которые, мы сделали курсивом. (скриншот [-@fig:005])

![Использование курсива в контрольных вопросах](photo/5.png){#fig:005 width=100%}

Последним шагом было подведение итогов - вывод. А также вывод списка литературы. скриншот [-@fig:006])

![Вывод и Список Литературы](photo/6.png){#fig:006 width=100%}

# Выводы

В ходе лабораторной работы мы научились оформлять отчёты с помощью легковесного языка разметки Markdown.

# Список литературы{.unnumbered}

https://esystem.rudn.ru/pluginfile.php/1383440/mod_resource/content/3/003-lab_markdown.pdf
:::
